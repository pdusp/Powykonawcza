# SimpleParser

It's a short demo how to write simple tokenizer that splits text line into list of values like double, string etc.
