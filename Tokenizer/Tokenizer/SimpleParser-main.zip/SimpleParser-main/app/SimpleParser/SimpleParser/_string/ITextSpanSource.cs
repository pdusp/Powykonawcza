﻿namespace SimpleParser
{
    public interface ITextSpanSource
    {
        string Text { get; }
    }
}